# private_pip_package
teste de instalavel pip privado

Se quiser instalar como geral, usa a linha:
### pip install git+ssh://git@github.com/arthurkafer/private_pip_package.git
