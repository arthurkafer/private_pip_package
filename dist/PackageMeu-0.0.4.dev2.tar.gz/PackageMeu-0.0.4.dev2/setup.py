#!/usr/bin/env python
from setuptools import setup

setup(
    setup_requires=['pbr', 'setuptools>=17.1'],
    pbr=True,
)